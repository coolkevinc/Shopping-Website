Instructions:

1. Place entire folder in *AMP root

2. Run tGE.sql in phpMyAdmin

3. Enjoy the site
