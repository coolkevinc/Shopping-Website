<?php include 'view/header.php'; ?>

<main>
<br/>
    <table align="center">
		<thead>
			<tr>
				<th style="" colspan="2;" font-size:="" font-weight:="" bold=""><center><h2>Categories</h2></center></th>
			</tr>
		</thead>
		<tbody>
			<tr>
				<td style="font-weight: bold"><a href="./product_catalog/?category_id=1"><img src="images/mon.jpg" width="200px"></a>
					<p><a href="./product_catalog/?category_id=1">Board Games</a></p>
				</td>
				<td style="font-weight: bold"><a href="./product_catalog/?category_id=2"><img src="images/uno.jpg" height="200px"></a>
					<p><a href="./product_catalog/?category_id=2">Card Games</a></p>
				</td>
			</tr>
			<tr>
				<td style="font-weight: bold"><a href="./product_catalog/?category_id=3"><img src="images/rubik.jpg" width="200px"></a>
					<p><a href="./product_catalog/?category_id=3">Puzzles</a></p>
				</td>
				<td style="font-weight: bold"><a href="./product_catalog/?category_id=4"><img src="images/yahtz.jpg" width="200px"></a>
					<p><a href="./product_catalog/?category_id=4">Miscellaneous</a></p>
				</td>
			</tr>
		</tbody>
	</table>
</main>

<?php include 'view/footer.php'; ?>
