<footer>
    <p class="copyright">
        &copy; <?php echo date("Y"); ?> !::!::!Gamers' Emporium!::!::!
    </p>
</footer>
</body>
</html>
