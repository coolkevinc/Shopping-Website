<?php 
//load cart for session

//make cart item

//add item to cart

//change quantity of item

//remove item

//empty the cart
?>
